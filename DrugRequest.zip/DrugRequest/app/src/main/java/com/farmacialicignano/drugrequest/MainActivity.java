package com.farmacialicignano.drugrequest;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        //noinspection SimplifiableIfStatement
        if (item.getItemId() == R.id.info) {
            Intent i = new Intent(this, Main2Activity.class);
            startActivityForResult(i, 0);
            return true;
        }

        return super.onOptionsItemSelected(item);

    }

    private void goToUrl(String url) {

        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));

    }

    private String retrieveText(int id) {

        //retrieves text from texboxes
        return ((EditText) findViewById(id)).getText().toString();

    }

    public void website(View view) {

        //defines website URL
        goToUrl(getString(R.string.webpage));

    }


    /**
     *
     * @param packageName the package name of the app to be checked
     * @return boolean value
     *
     */

    private boolean isAppInstalled(String packageName) {
        
        try {

            getPackageManager().getPackageInfo(packageName, PackageManager.GET_ACTIVITIES);
            return true;

        } catch (PackageManager.NameNotFoundException e) {

            return false;

        }

    }

    /**
     *
     * @param view
     * initialize variables for mail message
     * checks if fields are correctly filled in
     * opens chooser for mail clients
     * populates the target app
     *
     */

    public void mailReq(View view) {

        String tel_No = retrieveText(R.id.nbr),
                medicines = retrieveText(R.id.ReqTxt).trim(),
                _firstN = retrieveText(R.id.Name).trim(),
                _lastN = retrieveText(R.id.Cognome).trim();

        if(_firstN.equals("") || _lastN.equals("")
                || tel_No.equals("") || medicines.equals("")) {

            Toast.makeText(getApplicationContext(),
                    getString(R.string.ToastMsg), Toast.LENGTH_SHORT).show();

        } else if((tel_No).length() < 10){

            Toast.makeText(getApplicationContext(),
                    getString(R.string.NumShort), Toast.LENGTH_SHORT).show();

        } else {

            Intent intent = new Intent(Intent.ACTION_VIEW);

            intent.setData(Uri.parse("mailto:"));
            intent.putExtra(Intent.EXTRA_EMAIL,
                    new String [] { getString(R.string.mailAddr) });
            intent.putExtra(Intent.EXTRA_SUBJECT,
                    getString(R.string.ReqBody) + " " + _firstN + " " + _lastN);
            intent.putExtra(Intent.EXTRA_TEXT,
                    "Farmaci:\n" + medicines + "\n\nTel: " + tel_No);

            try {

                startActivity(Intent.createChooser(intent, getString(R.string.chooseApp)));

            } catch (ActivityNotFoundException e) {

                goToUrl(getString(R.string.mailApps));

            }

        }

    }

    /**
     *
     * @param view
     * initialize variables for whatsapp message
     * checks if fields are correctly filled in
     * opens whatsapp
     * populates the target app
     *
     */

    public void waMsg(View view) {

        //populate and send whatsapp message

        String _firstN = retrieveText(R.id.Name).trim(),
                msg = retrieveText(R.id.ReqTxt).trim(),
                _lastN = retrieveText(R.id.Cognome).trim();

        if(isAppInstalled("com.whatsapp")) {

            if (_firstN.equals("") || msg.equals("")
                    || _lastN.equals("")) {

                Toast.makeText(getApplicationContext(),
                        getString(R.string.ToastMsg), Toast.LENGTH_SHORT).show();

            } else {

                Intent sendIntent = new Intent(Intent.ACTION_SEND);

                sendIntent.putExtra("jid", getString(R.string.waContact));
                sendIntent.putExtra(Intent.EXTRA_TEXT, getString(R.string.ReqBody) + " "
                        + _firstN + " " + _lastN + "\n\n" + msg);
                sendIntent.setType("text/plain");
                sendIntent.setPackage("com.whatsapp");

                startActivity(sendIntent);

            }

        } else if (isAppInstalled("com.android.vending")) {

            goToUrl(getString(R.string.marketWa));

        } else {

            Toast.makeText(getApplicationContext(),
                    getString(R.string.StoreNotAvail), Toast.LENGTH_SHORT).show();

        }

    }

}